from django.apps import AppConfig


class ControllercloudfunctionConfig(AppConfig):
    name = 'ControllerCloudFunction'
